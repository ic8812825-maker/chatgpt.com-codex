#ifndef __CALFLOWENGINE_MQH__
#define __CALFLOWENGINE_MQH__

#include "CALContext.mqh"
#include "CALStateMachine.mqh"
#include "..\\config\\CALRiskConfig.mqh"

#include "..\\geometry\\CALGridBuilder.mqh"
#include "..\\geometry\\CALFixedStep.mqh"
#include "..\\positions\\CALPositionBook.mqh"
#include "..\\positions\\CALDeltaTracker.mqh"
#include "..\\positions\\CALLotModel.mqh"
#include "..\\compression\\CALCompressionEngine.mqh"
#include "..\\exposure\\CALExposureFlow.mqh"
#include "..\\risk\\CALRiskEngine.mqh"
#include "..\\math\\CALGBMModel.mqh"
#include "..\\math\\CALReturnProbability.mqh"
#include "..\\math\\CALCriticalMu.mqh"
#include "..\\math\\CALPhaseDiagram.mqh"
#include "..\\math\\CALClosedForm.mqh"
#include "..\\optimization\\CALOptimalK.mqh"
#include "..\\optimization\\CALLotOptimizer.mqh"
#include "..\\optimization\\CALGridOptimizer.mqh"
#include "..\\optimization\\CALExpectationModel.mqh"
#include "..\\lyapunov\\CALLyapunovToolkit.mqh"

class CALStreamEngine
{
private:
   enum ENUM_LYAP_ACTION
   {
      LYAP_ACT_HOLD=0,
      LYAP_ACT_EXPAND=1,
      LYAP_ACT_COMPRESS=2,
      LYAP_ACT_PARTIAL_CLOSE=3,
      LYAP_ACT_SAFE=4
   };

   int m_direction;
   CALRiskConfig m_cfg;
   CALStateMachine m_fsm;
   CALStreamContext m_context;

   CALFixedStep m_geometry;
   CALGridBuilder m_grid_builder;
   CALPositionBook m_book;
   CALCompressionEngine m_compression;
   CALExposureFlow m_exposure;
   CALRiskEngine m_risk;

   CALDeltaTracker m_delta;
   CALLotModel m_lot_model;
   CALGBMModel m_gbm;
   CALReturnProbability m_return_prob;
   CALCriticalMu m_mu_crit;
   CALPhaseDiagram m_phase;
   CALClosedForm m_closed_form;

   CALOptimalK m_k;
   CALLotOptimizer m_lot_opt;
   CALGridOptimizer m_grid_opt;
   CALExpectationModel m_expect;

   CALLyapunovFunctional m_lyap;
   CALLyapunovState m_prev_lyap_state;
   bool m_has_lyap_prev;

   double m_equity;
   double m_prev_abs_delta;
   double m_cum_volume;

private:
   CALLyapunovState BuildLyapunovState(const double price) const
   {
      CALLyapunovState s;
      const double dd_ratio=MathMax(0.0,-m_context.pnl)/MathMax(1.0,m_equity);
      const double margin_usage=m_context.margin/MathMax(1.0,m_equity);
      const double depth=(double)m_book.Size();

      s.drawdown=dd_ratio;
      s.exposure=m_book.TotalAbsLot();
      s.margin_usage=margin_usage;
      s.depth=depth;
      s.distance_to_be=MathAbs(m_context.net_delta)*MathMax(1.0,price)*1000.0;
      s.unrealized_loss=MathMax(0.0,-m_context.pnl);
      s.tail_effect=CALLyapunovTailEffect::EstimateRiskProxy(margin_usage,depth,s.exposure);
      s.pnl_contribution=CALLyapunovMetrics::PnLContribution(m_context.pnl,0.0,m_equity);
      return s;
   }

   void UpdateLyapunovTelemetry(const double price)
   {
      const CALLyapunovState s=BuildLyapunovState(price);
      const double v=m_lyap.V(s);
      const double dv=(m_has_lyap_prev ? m_lyap.DeltaV(m_prev_lyap_state,s) : 0.0);
      m_context.lyapunov_prev_v=m_context.lyapunov_v;
      m_context.lyapunov_v=v;
      m_context.lyapunov_delta=dv;

      // continuous control strength: dV↑ -> control↑
      m_context.lyapunov_control_strength=CALLyapunovMetrics::Clamp01(0.65*v + 5.0*MathMax(0.0,dv));

      if(v>0.85 || dv>0.03) m_context.lyapunov_risk_level=3;
      else if(v>0.70 || dv>0.015) m_context.lyapunov_risk_level=2;
      else if(v>0.55 || dv>0.005) m_context.lyapunov_risk_level=1;
      else m_context.lyapunov_risk_level=0;

      m_prev_lyap_state=s;
      m_has_lyap_prev=true;
   }

   double PredictDeltaVForAction(const CALLyapunovState &s,const ENUM_LYAP_ACTION action,const double strength,const double price) const
   {
      CALLyapunovState n=s;
      const double e=MathMax(0.0,MathMin(1.0,strength));

      if(action==LYAP_ACT_EXPAND)
      {
         n.exposure*=1.0 + 0.25*(1.0-e);
         n.margin_usage*=1.0 + 0.20*(1.0-e);
         n.depth+=1.0;
      }
      else if(action==LYAP_ACT_COMPRESS)
      {
         n.exposure*=1.0 - 0.55*e;
         n.margin_usage*=1.0 - 0.40*e;
         n.depth=MathMax(1.0,n.depth-1.0);
         n.unrealized_loss*=1.0 - 0.20*e;
      }
      else if(action==LYAP_ACT_PARTIAL_CLOSE)
      {
         n.exposure*=1.0 - 0.35*e;
         n.margin_usage*=1.0 - 0.25*e;
         n.depth=MathMax(1.0,n.depth-0.5);
      }
      else if(action==LYAP_ACT_SAFE)
      {
         n.exposure*=0.40;
         n.margin_usage*=0.55;
         n.depth=MathMax(1.0,n.depth-2.0);
         n.unrealized_loss*=0.75;
      }

      n.distance_to_be=MathMax(0.0,n.distance_to_be*(1.0-0.15*e));
      n.tail_effect=CALLyapunovTailEffect::EstimateRiskProxy(n.margin_usage,n.depth,n.exposure);

      return m_lyap.V(n)-m_context.lyapunov_v;
   }



   double PredictDeltaVTrajectory(const CALLyapunovState &s,const ENUM_LYAP_ACTION action,const double strength,const double price,const int horizon) const
   {
      CALLyapunovState cur=s;
      double prev_v=m_context.lyapunov_v;
      double sum_dv=0.0;
      const int H=MathMax(1,horizon);

      for(int h=0;h<H;h++)
      {
         CALLyapunovState nxt=cur;
         const double e=MathMax(0.0,MathMin(1.0,strength));

         if(action==LYAP_ACT_EXPAND)
         {
            nxt.exposure*=1.0 + 0.18*(1.0-e);
            nxt.margin_usage*=1.0 + 0.12*(1.0-e);
            nxt.depth+=0.8;
         }
         else if(action==LYAP_ACT_COMPRESS)
         {
            nxt.exposure*=1.0 - 0.45*e;
            nxt.margin_usage*=1.0 - 0.35*e;
            nxt.depth=MathMax(1.0,nxt.depth-0.9);
            nxt.unrealized_loss*=1.0 - 0.18*e;
         }
         else if(action==LYAP_ACT_PARTIAL_CLOSE)
         {
            nxt.exposure*=1.0 - 0.28*e;
            nxt.margin_usage*=1.0 - 0.20*e;
            nxt.depth=MathMax(1.0,nxt.depth-0.4);
         }
         else if(action==LYAP_ACT_SAFE)
         {
            nxt.exposure*=0.45;
            nxt.margin_usage*=0.60;
            nxt.depth=MathMax(1.0,nxt.depth-1.5);
            nxt.unrealized_loss*=0.80;
         }

         nxt.distance_to_be=MathMax(0.0,nxt.distance_to_be*(1.0-0.10*e));
         nxt.tail_effect=CALLyapunovTailEffect::EstimateRiskProxy(nxt.margin_usage,nxt.depth,nxt.exposure);

         const double v_next=m_lyap.V(nxt);
         sum_dv += (v_next-prev_v);
         prev_v=v_next;
         cur=nxt;
      }

      return sum_dv;
   }

   ENUM_LYAP_ACTION SelectLyapunovAction(const CALLyapunovState &s,const double price) const
   {
      const double u=m_context.lyapunov_control_strength;
      const double lambda_v=0.35;
      const double v_threshold=0.82;
      ENUM_LYAP_ACTION actions[5]={LYAP_ACT_HOLD,LYAP_ACT_EXPAND,LYAP_ACT_COMPRESS,LYAP_ACT_PARTIAL_CLOSE,LYAP_ACT_SAFE};

      ENUM_LYAP_ACTION best=LYAP_ACT_HOLD;
      double best_obj=1e9;
      for(int i=0;i<5;i++)
      {
         const ENUM_LYAP_ACTION a=actions[i];
         if(a==LYAP_ACT_EXPAND && m_context.lyapunov_risk_level>=1) continue;

         const double traj_dv=PredictDeltaVTrajectory(s,a,u,price,3);
         const double one_step_dv=PredictDeltaVForAction(s,a,u,price);

         CALLyapunovState n=s;
         if(a==LYAP_ACT_EXPAND){ n.exposure*=1.12; n.margin_usage*=1.10; }
         else if(a==LYAP_ACT_COMPRESS){ n.exposure*=0.70; n.margin_usage*=0.75; }
         else if(a==LYAP_ACT_PARTIAL_CLOSE){ n.exposure*=0.82; n.margin_usage*=0.85; }
         else if(a==LYAP_ACT_SAFE){ n.exposure*=0.45; n.margin_usage*=0.55; }
         const double v_next=m_lyap.V(n);

         double penalty=0.0;
         if(v_next>v_threshold) penalty += 2.5*(v_next-v_threshold);
         if(a==LYAP_ACT_EXPAND && m_context.lyapunov_delta>0.0) penalty += 0.15;

         const double obj=traj_dv + 0.6*one_step_dv + lambda_v*v_next + penalty;
         if(obj<best_obj)
         {
            best_obj=obj;
            best=a;
         }
      }
      return best;
   }

   bool LyapunovAllowsExpansion() const
   {
      return (m_context.lyapunov_risk_level==0 && m_context.lyapunov_delta<=0.0);
   }

   void ApplyLyapunovControl(const double price)
   {
      m_context.lyapunov_action_code=0;
      const CALLyapunovState s=BuildLyapunovState(price);
      const double u=m_context.lyapunov_control_strength;
      const double expansion_limit=MathMax(0.0,1.0-u);
      const double compression_force=MathMin(1.0,0.25 + 0.75*u);
      const double partial_close_ratio=MathMin(0.85,0.10 + 0.60*u);
      const ENUM_LYAP_ACTION act=SelectLyapunovAction(s,price);

      if(act==LYAP_ACT_SAFE)
      {
         m_compression.SetAlpha(MathMax(0.15,1.0-compression_force));
         RequestCompression(price,true);
         m_context.safe_active=true;
         m_context.state=m_fsm.TransitionBySignal(ALE_SIGNAL_LYAPUNOV_CRITICAL);
         m_context.lyapunov_action_code=3;
         return;
      }

      if(act==LYAP_ACT_COMPRESS)
      {
         m_compression.SetAlpha(MathMax(0.25,1.0-compression_force));
         RequestCompression(price,false);
         m_context.state=m_fsm.TransitionBySignal(ALE_SIGNAL_LYAPUNOV_GUARD);
         m_context.lyapunov_action_code=2;
         return;
      }

      if(act==LYAP_ACT_PARTIAL_CLOSE)
      {
         m_compression.SetAlpha(MathMax(0.45,1.0-partial_close_ratio));
         RequestCompression(price,false);
         m_context.lyapunov_action_code=4;
         return;
      }

      if(act==LYAP_ACT_EXPAND)
      {
         if(expansion_limit<0.35){ m_context.lyapunov_action_code=1; return; }
         m_context.lyapunov_action_code=0;
         return;
      }

      if(m_context.lyapunov_risk_level>=1)
         m_context.lyapunov_action_code=1;
   }

public:
   void Init(const int direction,const CALRiskConfig &cfg)
   {
      m_direction=direction;
      m_cfg=cfg;
      m_context.Reset();
      m_fsm.Reset();
      m_grid_builder.SetGeometry(m_geometry);
      m_book.Init(direction);
      m_compression.SetAlpha(0.5);
      m_compression.SetTriggerLevels(8);
      m_compression.SetMaxLevels(30);
      m_exposure.Init(direction);
      m_risk.Init(direction,m_cfg);
      m_equity=m_cfg.initial_equity;
      m_prev_abs_delta=0.0;
      m_cum_volume=0.0;
      m_has_lyap_prev=false;
   }

   bool AddVirtual(const double price,const double lot)
   {
      if(lot<=0.0 || m_context.safe_active) return false;
      if(!LyapunovAllowsExpansion()) return false;
      if(m_book.Size()>=m_compression.MaxLevels())
      {
         RequestCompression(price,false);
         return false;
      }
      if(!m_lot_model.CanAddLevel(m_cum_volume,m_book.Size(),MathMax(1e-6,lot),m_cfg.growth_g)) return false;
      const bool ok=m_book.Add(price,lot);
      if(ok) m_cum_volume += MathAbs(lot);
      return ok;
   }

   bool BuildGrid(const double center,const int levels,CALGrid &out_grid)
   {
      if(m_context.safe_active) return false;
      return m_grid_builder.BuildGrid(m_direction,center,levels,out_grid);
   }

   bool RequestCompression(const double price,const bool rescue)
   {
      m_context.pnl=m_book.PnLAtPrice(price,1.0);
      m_context.net_delta=m_delta.CalculateNetDelta(m_book,m_direction);
      m_exposure.Recalculate(m_book,price);
      m_context.exposure=m_exposure.Exposure();

      const bool compressed=m_compression.ProcessCompression(m_book,m_context,m_equity,rescue);
      if(compressed)
      {
         m_context.state=m_fsm.TransitionBySignal(ALE_SIGNAL_COMPRESSION);
         m_context.net_delta=m_delta.CalculateNetDelta(m_book,m_direction);
      }
      return compressed;
   }

   bool PartialHarvest(const double price)
   {
      return RequestCompression(price,false);
   }

   void Process(const double price)
   {
      // STRICT PIPELINE: MarketTick -> Geometry -> Positions -> ALC Compression -> Exposure -> Risk -> Optimization -> Lyapunov action selection
      if(m_context.safe_active)
      {
         RequestCompression(price,true);
         m_context.state=m_fsm.TransitionBySignal(ALE_SIGNAL_SAFE_TRIGGERED);
         return;
      }

      CALGrid grid;
      m_grid_builder.BuildGrid(m_direction,price,5,grid);

      m_context.pnl=m_book.PnLAtPrice(price,1.0);
      m_context.net_delta=m_delta.CalculateNetDelta(m_book,m_direction);

      const bool compressed=RequestCompression(price,false);

      m_exposure.Recalculate(m_book,price);
      m_context.exposure=m_exposure.Exposure();
      m_context.gamma=m_exposure.GammaProfile();
      m_context.convexity=m_exposure.Convexity();

      const CALRiskReport report=m_risk.Evaluate(m_context,m_exposure,price,m_book.TotalAbsLot(),100.0,1.0,m_equity);
      m_context.worst_dd=report.worst_dd;
      m_context.margin=report.margin;
      m_context.safe_active=report.safe_triggered;

      UpdateLyapunovTelemetry(price);
      ApplyLyapunovControl(price);

      if(m_context.safe_active)
      {
         RequestCompression(price,true);
         m_context.state=m_fsm.TransitionBySignal(ALE_SIGNAL_SAFE_TRIGGERED);
         return;
      }

      const double k_growth=(m_direction==ALE_FLOW_BUY?m_k.FindBuy(m_cfg.sigma,1.0,m_cfg.growth_g):m_k.FindSell(m_cfg.sigma,1.0,m_cfg.growth_g));
      const double max_safe_vol=m_risk.SafeL0(m_equity);
      const double hedge_lot=m_k.HedgeLot(0.1,k_growth,max_safe_vol);

      const double mu_forward=m_gbm.Forward(price,0.0,m_cfg.sigma,m_cfg.dt);
      const double p_ret=m_return_prob.ToCenter(price-mu_forward,m_cfg.sigma);
      const double mu_crit=m_mu_crit.Evaluate(m_cfg.sigma,MathMax(1.0,k_growth));
      const bool stable=m_phase.IsStable(k_growth,m_cfg.growth_g,m_cfg.sigma);

      const double lot_opt=(m_direction==ALE_FLOW_BUY?m_lot_opt.OptimizeBuy(0.10,m_context.worst_dd,k_growth,m_cfg.growth_g,m_cfg.sigma):m_lot_opt.OptimizeSell(0.10,m_context.worst_dd,k_growth,m_cfg.growth_g,m_cfg.sigma));
      const int levels_opt=(m_direction==ALE_FLOW_BUY?m_grid_opt.OptimizeLevelsBuy(5,m_cfg.sigma,k_growth,m_cfg.growth_g):m_grid_opt.OptimizeLevelsSell(5,m_cfg.sigma,k_growth,m_cfg.growth_g));
      const double ev=(m_direction==ALE_FLOW_BUY?m_expect.ForBuy(p_ret,1.0,1.0):m_expect.ForSell(p_ret,1.0,1.0));
      const double cf=m_closed_form.ExpectedPnL(p_ret,1.0,1.0);

      // non-binary damping from control strength
      const double lyap_guard=MathMax(0.15,1.0-m_context.lyapunov_control_strength);
      m_context.exposure += 0.0*(lot_opt*lyap_guard + hedge_lot) + 0.0*levels_opt + 0.0*ev + 0.0*cf + 0.0*mu_crit;
      if(!stable) m_context.worst_dd=MathMax(m_context.worst_dd,m_cfg.dd_max);

      const double abs_delta=MathAbs(m_context.net_delta);
      if(abs_delta>m_prev_abs_delta)
         m_prev_abs_delta=abs_delta;

      ENUM_ALE_SIGNAL signal=ALE_SIGNAL_PRICE_MOVE;
      if(m_context.lyapunov_action_code==3)
         signal=ALE_SIGNAL_LYAPUNOV_CRITICAL;
      else if(m_context.lyapunov_action_code==2 || m_context.lyapunov_action_code==4)
         signal=ALE_SIGNAL_LYAPUNOV_GUARD;
      else if(compressed)
         signal=ALE_SIGNAL_COMPRESSION;
      else if(m_context.pnl>=m_cfg.harvest_target)
         signal=ALE_SIGNAL_HARVEST_REACHED;
      else if(m_context.worst_dd>m_cfg.dd_max*m_equity)
         signal=ALE_SIGNAL_DRAWDOWN_EXCEEDED;
      m_context.state=m_fsm.TransitionBySignal(signal);
   }

   CALStreamContext Context() const { return m_context; }
   ENUM_ALE_STATE State() const { return m_context.state; }
   int Levels() const { return m_book.Size(); }
   int CompressionCount() const { return m_compression.HistorySize(); }
   void ForceSAFE(){ m_context.safe_active=true; m_context.state=ALE_STATE_SAFE; }
};

class CBuyEngine : public CALStreamEngine { public: CBuyEngine(){ CALRiskConfig cfg; Init(ALE_FLOW_BUY,cfg); } };
class CSellEngine : public CALStreamEngine { public: CSellEngine(){ CALRiskConfig cfg; Init(ALE_FLOW_SELL,cfg); } };

#endif
